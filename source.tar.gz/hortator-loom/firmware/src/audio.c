/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* I2S output (ALNK0 -> external codec) and the audio ISR: each half buffer is
 * rendered in blocks of CTL samples by mix_block (fx.c: events -> each drum track
 * -> dist -> level / pan -> sends -> buses -> master), then scaled to 24-bit stereo. */
/* registers: hal/fm1_audio.h */
#define HALF_WORDS (HALF_FRAMES * 2u)
#define OUT_SHIFT 7               /* Q15 -> 24-bit, -6 dBFS ceiling */

static int32_t abuf[2u * HALF_WORDS] __attribute__((aligned(4)));

/* diagnostics, kept across resets and UBOOT entry: read with `fm1t memr` */
#define DBG_MAGIC 0x44424731u                       /* "DBG1" */
struct felucca_dbg {
    uint32_t magic, halves, max_us, nested, in_audio, late, timer_irqs, ui_frames;
    uint32_t last_us, cpu_q8, boots;
    uint32_t stage, page, home;           /* where the main loop is (breadcrumbs) */
    uint32_t prev_stage, prev_page, prev_home, prev_rst, prev_frames;   /* as found at boot */
} felucca_dbg __attribute__((section(".noinit")));
static volatile uint32_t audio_halves, audio_max_us;
static volatile uint32_t t5_nested_ticks;              /* TIMER4 ticks TIMER5 spent nested in this ISR (main.c, upstream 1.0) */
#define SCOPE_N 512u
static int16_t scope_buf[SCOPE_N];
static uint32_t scope_w;

static void audio_block(int32_t *out, uint32_t n)       /* mix (fx.c), then Q15 -> 24 bit */
{
    uint32_t i;
    mix_block(out, n);
#if FELUCCA_UAC
#if USB8_OK
    if (usb10)
        uac8_tap(usb8_main(out, n), n);                 /* MENU > USB AUDIO 10 CH: the master (MIX) or the send
                                                         * effects (FX) + the tracks (fx.c) */
    else
#endif
        uac_tap(out, n);                                /* the USB audio input: the same master output */
#endif
    if (fx_usb_fixed)                                   /* USB LEVEL FIXED: USB took the full level, the DAC */
        usb_fixed_dac(out, n);                          /* (speaker, headphones) gets MASTER's (fx.c) */
    for (i = 0; i < n; i++) {
        if (i & 1u)
            scope_buf[scope_w++ & (SCOPE_N - 1u)] = (int16_t)out[2u * i];
        out[2u * i] *= 1 << OUT_SHIFT;               /* (upstream 1.0) a negative left shift is undefined */
        out[2u * i + 1u] *= 1 << OUT_SHIFT;
    }
}

/* overload: a half that took > 85 % of its time (owner 2026-11-03; 95 % from 0.16.0 let rare spikes past 100 %) sheds one voice before the next one: a LOW track's oldest
 * sounding drum voice first, else the oldest (drum_shed, the declick tail); song.sheds counts them (the top bar's CPU
 * icon, the console). */
static volatile uint8_t shed_req;

static void shed_voice(void)
{
    drum_shed();
    song.sheds++;
}

#if FELUCCA_BLE
#if BLE_CONSOLE
static uint32_t audio_t0_prev, audio_gap_max;      /* the half interrupts' entries: the longest gap (ticks; nominal
                                                    * HALF_FRAMES samples, 5.8 ms), for the console's `ble` */
#endif
#define BT_FML_HEARD_AUDIO 1
static uint32_t bt_fml_heard;                      /* the tick the block being rendered is heard at (bt_fml.c: FM-Link) */
#endif
void fm1_alnk0_irq(void)                       /* via isr_alnk0 (hal/fm1_isr.S) */
{
    uint8_t p;
    uint32_t t0, t1;
    felucca_dbg.in_audio = 1;                   /* (upstream 1.0) first: TIMER5 nests from here on (main.c) */
    p = fm1_audio_pending();
    t0 = fm1_ticks();
#if FELUCCA_BLE && BLE_CONSOLE
    if (p & FM1_AUDIO_HALF) {                   /* (held off: a gap longer than a half) */
        if (t0 - audio_t0_prev > audio_gap_max)
            audio_gap_max = t0 - audio_t0_prev;
        audio_t0_prev = t0;
    }
#endif
    t5_nested_ticks = 0;
    fm1_audio_ack_aux(p);
    if (p & FM1_AUDIO_HALF) {
        uint32_t half = fm1_audio_free_half(), b, us;
        int32_t *o = &abuf[half * HALF_WORDS], *r = bench.mode ? bench.out : o;   /* BENCH LIVE: not heard */
        uint32_t rest = bench.mode && bench_rest();     /* BENCH (bench.c): HOLD, or a rest after a heavy half */
        if (shed_req) {
            shed_req = 0;
            shed_voice();
        }
        mout_half(t0);                                  /* midi_out.c: SYNC's Clocks are timed from this IRQ */
#if FELUCCA_UAC
#if USB8_OK
        if (usb10)
            uac8_render_start();                        /* MENU > USB AUDIO 10 CH */
        else
#endif
            uac_render_start();
#endif
        if (!rest)
            for (b = 0; b < HALF_FRAMES; b += CTL) {
#if FELUCCA_BLE
                bt_fml_heard = t0 + (HALF_FRAMES + b) * 544u;   /* (the free half plays after the one playing:
                                                     * 544 TIMER4 ticks a sample, fmlink.c FML_TPS) */
#endif
                audio_block(r + 2u * b, CTL);
            }
        if (bench.mode)
            bench_mute(o);                              /* the DAC: silence */
        fm1_audio_ack_half();
        audio_halves++;
        t1 = fm1_ticks();
        mout_half_done(t1);                             /* .. and the render's end (USB sends again after it) */
        us = (t1 - t0 - t5_nested_ticks) / FM1_TICKS_PER_US;   /* the render alone */
        if (us > audio_max_us)
            audio_max_us = us;
        if (bench.mode) {                               /* BENCH: timed, never shed */
            if (!rest)
                bench_time(us, fm1_audio_free_half() != half);
        } else if (us * 100u > (HALF_FRAMES * 1000000u / FS) * 85u) {
            shed_req = 1;
        }
        {                                             /* (upstream 1.0) the IIR keeps its remainder: no low bias */
            uint32_t load = song.cpu_q8 * 15u + (us * 256u) / (HALF_FRAMES * 1000000u / FS) + song.cpu_rem;
            song.cpu_q8 = load / 16u;
            song.cpu_rem = load % 16u;
        }
        if (fm1_audio_free_half() != half)
            felucca_dbg.late++;                         /* the DMA moved on while we rendered */
        felucca_dbg.halves++;
        felucca_dbg.last_us = us;
        if (us > felucca_dbg.max_us)
            felucca_dbg.max_us = us;
        felucca_dbg.cpu_q8 = song.cpu_q8;
    }
    felucca_dbg.in_audio = 0;
}
extern void isr_alnk0(void);

static void audio_init(void)                   /* hal/fm1_audio.h */
{
    uint32_t i;
    for (i = 0; i < 2u * HALF_WORDS; i++)
        abuf[i] = 0;
    fm1_audio_init(abuf, HALF_WORDS, isr_alnk0, 3);
}
